﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    public partial class frmFazerPedido : Form
    {
        List<Cliente> listClientes;
        List<Produto> listprodutos;
        List<PedidoCompra> listapedidos;

        // versão atual, apagar após atualizar
        public frmFazerPedido(List<Cliente> clientes, List<Produto> produtos)
        {
            InitializeComponent();
            this.listClientes = clientes;
            this.listprodutos = produtos;
            listapedidos = new List<PedidoCompra>();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            lvwExibirInfoCliente.Items.Clear(); // Limpa o ListView antes de buscar

            bool encontrado = false;

            foreach (var cliente in listClientes)
            {
                if ((rbtnCPF.Checked && cliente.CPF == txtPesquisarCliente.Text) ||
                    (rbtnNome.Checked && cliente.Nome.Equals(txtPesquisarCliente.Text, StringComparison.OrdinalIgnoreCase)))
                {
                    // Adiciona o cliente ao ListView
                    ListViewItem item = new ListViewItem(cliente.CPF);
                    item.SubItems.Add(cliente.Nome);
                    item.SubItems.Add(cliente.Sexo);
                    item.SubItems.Add(cliente.Logradouro);
                    item.SubItems.Add(cliente.Cidade);
                    item.SubItems.Add(cliente.Estado);
                    item.SubItems.Add(cliente.Pais);
                    item.SubItems.Add(cliente.Saldo.ToString());
                    lvwExibirInfoCliente.Items.Add(item);
                    encontrado = true;
                }
            }

            if (!encontrado)
            {
                MessageBox.Show("Usuário não encontrado.");
            }
        }

        private List<ItemCompra> itensDoPedidoAtual = new List<ItemCompra>();

        private void btnAddProdutoPedido_Click(object sender, EventArgs e)
        {
    //frmAdicionarProduto adicionarProdutoForm = new frmAdicionarProduto(listprodutos);
    //adicionarProdutoForm.ShowDialog();

            cmbNomeProduto.DataSource = null; // Força atualização do ComboBox
            cmbNomeProduto.DataSource = listprodutos; // Recarrega a lista atualizada
            cmbNomeProduto.DisplayMember = "Nome";
            cmbNomeProduto.ValueMember = "ID";

        // Obter o cliente e o produto selecionados
        Produto produtoSelecionado = (Produto)cmbNomeProduto.SelectedItem;

            // Verificar se um produto foi selecionado
            if (produtoSelecionado == null)
            {
                MessageBox.Show("Por favor, selecione um produto.");
                return;
            }

            // Validar a quantidade
            int quantidade;
            if (!int.TryParse(txtQtd.Text, out quantidade) || quantidade <= 0)
            {
                MessageBox.Show("Por favor, insira uma quantidade válida.");
                return;
            }

            // Verificar o estoque
            if (quantidade > produtoSelecionado.Estoque)
            {
                MessageBox.Show("Quantidade insuficiente no estoque.");
                return;
            }

            // Criar o item do pedido
            ItemCompra item = new ItemCompra(produtoSelecionado, Convert.ToDouble(txtQtd.Text))
            {
                Produto = produtoSelecionado, // Preencher com o produto selecionado
                Quantidade = quantidade       // Preencher com a quantidade informada
            };

            itensDoPedidoAtual.Add(item);
            // Atualizar o estoque
            produtoSelecionado.Estoque -= quantidade;

            ListViewItem listItem = new ListViewItem(produtoSelecionado.Nome);
            listItem.SubItems.Add(quantidade.ToString());
            listItem.SubItems.Add((produtoSelecionado.Valor * quantidade).ToString("C")); // Subtotal
            lvwExibirPedido.Items.Add(listItem);

            MessageBox.Show("Produto adicionado ao pedido.");
        }

        private void btnFinalizarPedido_Click(object sender, EventArgs e)
        {
            if (itensDoPedidoAtual.Count == 0)
            {
                MessageBox.Show("Nenhum produto foi adicionado ao pedido.");
                return;
            }

            // Obter cliente selecionado
            Cliente clienteSelecionado = null;
            if (lvwExibirInfoCliente.SelectedItems.Count > 0)
            {
                string cpf = lvwExibirInfoCliente.SelectedItems[0].Text;
                clienteSelecionado = listClientes.FirstOrDefault(c => c.CPF == cpf);
            }

            if (clienteSelecionado == null)
            {
                MessageBox.Show("Selecione um cliente válido.");
                return;
            }

            // Criar pedido
            PedidoCompra pedido = new PedidoCompra
            {
                Cliente = clienteSelecionado, // Associar o cliente ao pedido
                Itens = itensDoPedidoAtual,
                DataHora = DateTime.Now,
                Status = "pendente"
            };


            // Add pedido à lista
            listapedidos.Add(pedido);

            double valorTotal = itensDoPedidoAtual.Sum(i => i.Produto.Valor * i.Quantidade);

            // Exibir o total
            MessageBox.Show($"Pedido finalizado com sucesso! Valor total: {valorTotal:C}");

            // Limpar as listas e campos
            itensDoPedidoAtual.Clear();
            lvwExibirPedido.Items.Clear();
            lvwExibirInfoCliente.Items.Clear();
            txtPesquisarCliente.Clear();
            txtQtd.Clear();
        }

        private void btnCancelarPedido_Click(object sender, EventArgs e)
        {

        }

        private void frmFazerPedido_Load(object sender, EventArgs e)
        {
            AtualizarComboBoxProdutos();
        }

        public void AtualizarComboBoxProdutos()
        {
            cmbNomeProduto.DataSource = null; // Limpa o DataSource anterior
            cmbNomeProduto.DataSource = listprodutos; // Recarrega os produtos
            cmbNomeProduto.DisplayMember = "Nome";
            cmbNomeProduto.ValueMember = "ID";
        }

    }
}






