﻿namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    partial class frmFazerPedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAddProdutoPedido = new System.Windows.Forms.Button();
            this.btnFinalizarPedido = new System.Windows.Forms.Button();
            this.lvwExibirInfoCliente = new System.Windows.Forms.ListView();
            this.txtPesquisarCliente = new System.Windows.Forms.TextBox();
            this.rbtnCPF = new System.Windows.Forms.RadioButton();
            this.rbtnNome = new System.Windows.Forms.RadioButton();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.cmbNomeProduto = new System.Windows.Forms.ComboBox();
            this.txtQtd = new System.Windows.Forms.TextBox();
            this.lvwExibirPedido = new System.Windows.Forms.ListView();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCancelarPedido = new System.Windows.Forms.Button();
            this.CPF = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Nome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NomeProduto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.QtdProduto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ValorProduto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SaldoConta = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Genero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Logradouro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Cidade = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Estado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Pais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nome ou CPF:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Quantidade pedida:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 42);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nome do produto:";
            // 
            // btnAddProdutoPedido
            // 
            this.btnAddProdutoPedido.Location = new System.Drawing.Point(466, 42);
            this.btnAddProdutoPedido.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddProdutoPedido.Name = "btnAddProdutoPedido";
            this.btnAddProdutoPedido.Size = new System.Drawing.Size(94, 61);
            this.btnAddProdutoPedido.TabIndex = 6;
            this.btnAddProdutoPedido.Text = "Adicionar Produto ao pedido";
            this.btnAddProdutoPedido.UseVisualStyleBackColor = true;
            this.btnAddProdutoPedido.Click += new System.EventHandler(this.btnAddProdutoPedido_Click);
            // 
            // btnFinalizarPedido
            // 
            this.btnFinalizarPedido.Location = new System.Drawing.Point(440, 469);
            this.btnFinalizarPedido.Margin = new System.Windows.Forms.Padding(4);
            this.btnFinalizarPedido.Name = "btnFinalizarPedido";
            this.btnFinalizarPedido.Size = new System.Drawing.Size(91, 48);
            this.btnFinalizarPedido.TabIndex = 7;
            this.btnFinalizarPedido.Text = "Finalizar pedido";
            this.btnFinalizarPedido.UseVisualStyleBackColor = true;
            this.btnFinalizarPedido.Click += new System.EventHandler(this.btnFinalizarPedido_Click);
            // 
            // lvwExibirInfoCliente
            // 
            this.lvwExibirInfoCliente.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CPF,
            this.Nome,
            this.Genero,
            this.Logradouro,
            this.Cidade,
            this.Estado,
            this.Pais,
            this.SaldoConta});
            this.lvwExibirInfoCliente.FullRowSelect = true;
            this.lvwExibirInfoCliente.GridLines = true;
            this.lvwExibirInfoCliente.HideSelection = false;
            this.lvwExibirInfoCliente.Location = new System.Drawing.Point(30, 149);
            this.lvwExibirInfoCliente.Margin = new System.Windows.Forms.Padding(4);
            this.lvwExibirInfoCliente.Name = "lvwExibirInfoCliente";
            this.lvwExibirInfoCliente.Size = new System.Drawing.Size(689, 195);
            this.lvwExibirInfoCliente.TabIndex = 9;
            this.lvwExibirInfoCliente.UseCompatibleStateImageBehavior = false;
            this.lvwExibirInfoCliente.View = System.Windows.Forms.View.Details;
            // 
            // txtPesquisarCliente
            // 
            this.txtPesquisarCliente.Location = new System.Drawing.Point(168, 10);
            this.txtPesquisarCliente.Margin = new System.Windows.Forms.Padding(4);
            this.txtPesquisarCliente.Name = "txtPesquisarCliente";
            this.txtPesquisarCliente.Size = new System.Drawing.Size(159, 22);
            this.txtPesquisarCliente.TabIndex = 10;
            // 
            // rbtnCPF
            // 
            this.rbtnCPF.AutoSize = true;
            this.rbtnCPF.Location = new System.Drawing.Point(355, 11);
            this.rbtnCPF.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnCPF.Name = "rbtnCPF";
            this.rbtnCPF.Size = new System.Drawing.Size(54, 20);
            this.rbtnCPF.TabIndex = 11;
            this.rbtnCPF.TabStop = true;
            this.rbtnCPF.Text = "CPF";
            this.rbtnCPF.UseVisualStyleBackColor = true;
            // 
            // rbtnNome
            // 
            this.rbtnNome.AutoSize = true;
            this.rbtnNome.Location = new System.Drawing.Point(355, 43);
            this.rbtnNome.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnNome.Name = "rbtnNome";
            this.rbtnNome.Size = new System.Drawing.Size(65, 20);
            this.rbtnNome.TabIndex = 12;
            this.rbtnNome.TabStop = true;
            this.rbtnNome.Text = "Nome";
            this.rbtnNome.UseVisualStyleBackColor = true;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(355, 71);
            this.btnBuscar.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(71, 43);
            this.btnBuscar.TabIndex = 13;
            this.btnBuscar.Text = "Buscar cliente";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // cmbNomeProduto
            // 
            this.cmbNomeProduto.FormattingEnabled = true;
            this.cmbNomeProduto.Location = new System.Drawing.Point(168, 38);
            this.cmbNomeProduto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbNomeProduto.Name = "cmbNomeProduto";
            this.cmbNomeProduto.Size = new System.Drawing.Size(159, 24);
            this.cmbNomeProduto.TabIndex = 15;
            // 
            // txtQtd
            // 
            this.txtQtd.Location = new System.Drawing.Point(168, 74);
            this.txtQtd.Margin = new System.Windows.Forms.Padding(4);
            this.txtQtd.Name = "txtQtd";
            this.txtQtd.Size = new System.Drawing.Size(159, 22);
            this.txtQtd.TabIndex = 16;
            // 
            // lvwExibirPedido
            // 
            this.lvwExibirPedido.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.NomeProduto,
            this.QtdProduto,
            this.ValorProduto});
            this.lvwExibirPedido.FullRowSelect = true;
            this.lvwExibirPedido.GridLines = true;
            this.lvwExibirPedido.HideSelection = false;
            this.lvwExibirPedido.Location = new System.Drawing.Point(30, 377);
            this.lvwExibirPedido.Margin = new System.Windows.Forms.Padding(4);
            this.lvwExibirPedido.Name = "lvwExibirPedido";
            this.lvwExibirPedido.Size = new System.Drawing.Size(345, 195);
            this.lvwExibirPedido.TabIndex = 17;
            this.lvwExibirPedido.UseCompatibleStateImageBehavior = false;
            this.lvwExibirPedido.View = System.Windows.Forms.View.Details;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(87, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "Exibir os usuarios pesquisados";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(87, 357);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(255, 16);
            this.label5.TabIndex = 19;
            this.label5.Text = "exibir os produtos adicionados no pedido";
            // 
            // btnCancelarPedido
            // 
            this.btnCancelarPedido.Location = new System.Drawing.Point(440, 377);
            this.btnCancelarPedido.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelarPedido.Name = "btnCancelarPedido";
            this.btnCancelarPedido.Size = new System.Drawing.Size(91, 48);
            this.btnCancelarPedido.TabIndex = 20;
            this.btnCancelarPedido.Text = "Cancelar pedido";
            this.btnCancelarPedido.UseVisualStyleBackColor = true;
            this.btnCancelarPedido.Click += new System.EventHandler(this.btnCancelarPedido_Click);
            // 
            // CPF
            // 
            this.CPF.Text = "CPF";
            // 
            // Nome
            // 
            this.Nome.Text = "Nome";
            // 
            // NomeProduto
            // 
            this.NomeProduto.Text = "Nome";
            this.NomeProduto.Width = 100;
            // 
            // QtdProduto
            // 
            this.QtdProduto.Text = "Quantidade";
            this.QtdProduto.Width = 100;
            // 
            // ValorProduto
            // 
            this.ValorProduto.Text = "Valor";
            this.ValorProduto.Width = 100;
            // 
            // SaldoConta
            // 
            this.SaldoConta.Text = "Saldo";
            // 
            // Genero
            // 
            this.Genero.Text = "Genero";
            // 
            // Logradouro
            // 
            this.Logradouro.Text = "Logradouro";
            this.Logradouro.Width = 82;
            // 
            // Cidade
            // 
            this.Cidade.Text = "Cidade";
            // 
            // Estado
            // 
            this.Estado.Text = "Estado";
            // 
            // Pais
            // 
            this.Pais.Text = "País";
            // 
            // frmFazerPedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(792, 585);
            this.Controls.Add(this.btnCancelarPedido);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lvwExibirPedido);
            this.Controls.Add(this.txtQtd);
            this.Controls.Add(this.cmbNomeProduto);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.rbtnNome);
            this.Controls.Add(this.rbtnCPF);
            this.Controls.Add(this.txtPesquisarCliente);
            this.Controls.Add(this.lvwExibirInfoCliente);
            this.Controls.Add(this.btnFinalizarPedido);
            this.Controls.Add(this.btnAddProdutoPedido);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmFazerPedido";
            this.Text = "frmFazerPedido";
            this.Load += new System.EventHandler(this.frmFazerPedido_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAddProdutoPedido;
        private System.Windows.Forms.Button btnFinalizarPedido;
        private System.Windows.Forms.ListView lvwExibirInfoCliente;
        private System.Windows.Forms.TextBox txtPesquisarCliente;
        private System.Windows.Forms.RadioButton rbtnCPF;
        private System.Windows.Forms.RadioButton rbtnNome;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.ComboBox cmbNomeProduto;
        private System.Windows.Forms.TextBox txtQtd;
        private System.Windows.Forms.ListView lvwExibirPedido;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCancelarPedido;
        private System.Windows.Forms.ColumnHeader CPF;
        private System.Windows.Forms.ColumnHeader Nome;
        private System.Windows.Forms.ColumnHeader NomeProduto;
        private System.Windows.Forms.ColumnHeader QtdProduto;
        private System.Windows.Forms.ColumnHeader ValorProduto;
        private System.Windows.Forms.ColumnHeader SaldoConta;
        private System.Windows.Forms.ColumnHeader Genero;
        private System.Windows.Forms.ColumnHeader Logradouro;
        private System.Windows.Forms.ColumnHeader Cidade;
        private System.Windows.Forms.ColumnHeader Estado;
        private System.Windows.Forms.ColumnHeader Pais;
    }
}