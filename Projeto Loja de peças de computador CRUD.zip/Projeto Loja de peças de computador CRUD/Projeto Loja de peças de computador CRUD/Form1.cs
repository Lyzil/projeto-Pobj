﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        frmAdicionarProduto frmAdicionarProdutoobj;
        frmAdicionarCliente frmAdicionarClienteobj;
        frmAdicionarCliente frmFazerPedidoobj;
        private void tsmiProdutos_Click(object sender, EventArgs e)
        {

            if (frmAdicionarProdutoobj == null || frmAdicionarProdutoobj.IsDisposed)
            {
                frmAdicionarProduto frmAdicionarProdutoobj = new frmAdicionarProduto();
                frmAdicionarProdutoobj.MdiParent = this;
                frmAdicionarProdutoobj.Show();
            }
            else { frmFazerPedidoobj.Show(); }

        }

        private void tsmiCliente_Click(object sender, EventArgs e)
        {
            if (frmAdicionarClienteobj == null || frmAdicionarClienteobj.IsDisposed)
            {
                frmAdicionarCliente frmAdicionarClienteobj = new frmAdicionarCliente();
                frmAdicionarClienteobj.MdiParent = this;
                frmAdicionarClienteobj.Show();
            }
            else { frmFazerPedidoobj.Show(); }
        }

        private void tsmiPedido_Click(object sender, EventArgs e)
        {
            if (frmFazerPedidoobj == null || frmFazerPedidoobj.IsDisposed)
            {
                frmFazerPedido frmFazerPedidoobj = new frmFazerPedido();
                frmFazerPedidoobj.MdiParent = this;
                frmFazerPedidoobj.Show();
            }
            else {frmFazerPedidoobj.Show(); }
        }
    }
}
