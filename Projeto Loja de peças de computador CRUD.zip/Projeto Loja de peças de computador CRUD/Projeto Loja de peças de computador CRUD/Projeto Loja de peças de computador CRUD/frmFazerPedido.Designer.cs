﻿namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    partial class frmFazerPedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nudQtd = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomeProduto = new System.Windows.Forms.TextBox();
            this.btnAddProdutoPedido = new System.Windows.Forms.Button();
            this.btnFinalizarPedido = new System.Windows.Forms.Button();
            this.lvwExibirInfoCliente = new System.Windows.Forms.ListView();
            this.txtPesquisarCliente = new System.Windows.Forms.TextBox();
            this.rbtnCPF = new System.Windows.Forms.RadioButton();
            this.rbtnNome = new System.Windows.Forms.RadioButton();
            this.btnBuscar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudQtd)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "nOME OU CPF";
            // 
            // nudQtd
            // 
            this.nudQtd.Location = new System.Drawing.Point(123, 75);
            this.nudQtd.Name = "nudQtd";
            this.nudQtd.Size = new System.Drawing.Size(120, 20);
            this.nudQtd.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Quantidade pedida:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nome do produto:";
            // 
            // txtNomeProduto
            // 
            this.txtNomeProduto.Location = new System.Drawing.Point(123, 49);
            this.txtNomeProduto.Name = "txtNomeProduto";
            this.txtNomeProduto.Size = new System.Drawing.Size(120, 20);
            this.txtNomeProduto.TabIndex = 5;
            // 
            // btnAddProdutoPedido
            // 
            this.btnAddProdutoPedido.Location = new System.Drawing.Point(270, 159);
            this.btnAddProdutoPedido.Name = "btnAddProdutoPedido";
            this.btnAddProdutoPedido.Size = new System.Drawing.Size(112, 23);
            this.btnAddProdutoPedido.TabIndex = 6;
            this.btnAddProdutoPedido.Text = "Adicionar Produto";
            this.btnAddProdutoPedido.UseVisualStyleBackColor = true;
            this.btnAddProdutoPedido.Click += new System.EventHandler(this.btnAddProdutoPedido_Click);
            // 
            // btnFinalizarPedido
            // 
            this.btnFinalizarPedido.Location = new System.Drawing.Point(270, 188);
            this.btnFinalizarPedido.Name = "btnFinalizarPedido";
            this.btnFinalizarPedido.Size = new System.Drawing.Size(112, 23);
            this.btnFinalizarPedido.TabIndex = 7;
            this.btnFinalizarPedido.Text = "Finalizar pedido";
            this.btnFinalizarPedido.UseVisualStyleBackColor = true;
            this.btnFinalizarPedido.Click += new System.EventHandler(this.btnFinalizarPedido_Click);
            // 
            // lvwExibirInfoCliente
            // 
            this.lvwExibirInfoCliente.HideSelection = false;
            this.lvwExibirInfoCliente.Location = new System.Drawing.Point(20, 118);
            this.lvwExibirInfoCliente.Name = "lvwExibirInfoCliente";
            this.lvwExibirInfoCliente.Size = new System.Drawing.Size(223, 159);
            this.lvwExibirInfoCliente.TabIndex = 9;
            this.lvwExibirInfoCliente.UseCompatibleStateImageBehavior = false;
            // 
            // txtPesquisarCliente
            // 
            this.txtPesquisarCliente.Location = new System.Drawing.Point(123, 23);
            this.txtPesquisarCliente.Name = "txtPesquisarCliente";
            this.txtPesquisarCliente.Size = new System.Drawing.Size(120, 20);
            this.txtPesquisarCliente.TabIndex = 10;
            // 
            // rbtnCPF
            // 
            this.rbtnCPF.AutoSize = true;
            this.rbtnCPF.Location = new System.Drawing.Point(263, 24);
            this.rbtnCPF.Name = "rbtnCPF";
            this.rbtnCPF.Size = new System.Drawing.Size(45, 17);
            this.rbtnCPF.TabIndex = 11;
            this.rbtnCPF.TabStop = true;
            this.rbtnCPF.Text = "CPF";
            this.rbtnCPF.UseVisualStyleBackColor = true;
            // 
            // rbtnNome
            // 
            this.rbtnNome.AutoSize = true;
            this.rbtnNome.Location = new System.Drawing.Point(329, 24);
            this.rbtnNome.Name = "rbtnNome";
            this.rbtnNome.Size = new System.Drawing.Size(53, 17);
            this.rbtnNome.TabIndex = 12;
            this.rbtnNome.TabStop = true;
            this.rbtnNome.Text = "Nome";
            this.rbtnNome.UseVisualStyleBackColor = true;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(270, 49);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(112, 23);
            this.btnBuscar.TabIndex = 13;
            this.btnBuscar.Text = "Buscar cliente";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // frmFazerPedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(416, 313);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.rbtnNome);
            this.Controls.Add(this.rbtnCPF);
            this.Controls.Add(this.txtPesquisarCliente);
            this.Controls.Add(this.lvwExibirInfoCliente);
            this.Controls.Add(this.btnFinalizarPedido);
            this.Controls.Add(this.btnAddProdutoPedido);
            this.Controls.Add(this.txtNomeProduto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nudQtd);
            this.Controls.Add(this.label1);
            this.Name = "frmFazerPedido";
            this.Text = "frmFazerPedido";
            ((System.ComponentModel.ISupportInitialize)(this.nudQtd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudQtd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNomeProduto;
        private System.Windows.Forms.Button btnAddProdutoPedido;
        private System.Windows.Forms.Button btnFinalizarPedido;
        private System.Windows.Forms.ListView lvwExibirInfoCliente;
        private System.Windows.Forms.TextBox txtPesquisarCliente;
        private System.Windows.Forms.RadioButton rbtnCPF;
        private System.Windows.Forms.RadioButton rbtnNome;
        private System.Windows.Forms.Button btnBuscar;
    }
}