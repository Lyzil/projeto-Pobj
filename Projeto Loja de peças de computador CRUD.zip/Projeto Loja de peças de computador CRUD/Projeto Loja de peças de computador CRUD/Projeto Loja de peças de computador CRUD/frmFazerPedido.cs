﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    public partial class frmFazerPedido : Form
    {
        List<Cliente> listClientes;
        List<Produto> listprodutos;
        List<ItemCompra> pedidos;

        // public frmFazerPedido(object clientes, object produtos)
        public frmFazerPedido()
        {
            InitializeComponent();
            //this.listClientes = clientes;
            //this.listprodutos  = produtos;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (rbtnCPF.Checked)
            {
                //txtPesquisarCliente
            }
            else if (rbtnNome.Checked)
            {

            }
        }

        private void btnAddProdutoPedido_Click(object sender, EventArgs e)
        {
            
                
        }

        private void btnFinalizarPedido_Click(object sender, EventArgs e)
        {
            
        }

        
    }
}
