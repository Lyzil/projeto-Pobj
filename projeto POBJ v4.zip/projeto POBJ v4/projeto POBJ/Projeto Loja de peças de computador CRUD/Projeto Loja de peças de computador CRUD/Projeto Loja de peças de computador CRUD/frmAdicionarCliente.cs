﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    public partial class frmAdicionarCliente : Form
    {
        List<Cliente> listaclientes;
        Cliente cliente;
        public frmAdicionarCliente(List<Cliente> clientes)
        {
            InitializeComponent();
            listaclientes = clientes;
        }

        private void btnAddCliente_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtCPF.Text) || txtCPF.Text.Length != 11 || !txtCPF.Text.All(char.IsDigit))
                {
                    MessageBox.Show("CPF inválido. Deve conter exatamente 11 dígitos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrEmpty(txtNomeCliente.Text))
                {
                    MessageBox.Show("Nome não pode ser vazio.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrEmpty(txtSexo.Text) || (txtSexo.Text.ToUpper() != "M" && txtSexo.Text.ToUpper() != "F"))
                {
                    MessageBox.Show("Sexo inválido. Deve ser 'M' (masculino) ou 'F' (feminino).", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (string.IsNullOrEmpty(txtCidade.Text))
                {
                    MessageBox.Show("Cidade não pode ser vazia.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (string.IsNullOrEmpty(txtLagradouro.Text))
                {
                    MessageBox.Show("Logradouro não pode ser vazio.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (string.IsNullOrEmpty(txtEstado.Text))
                {
                    MessageBox.Show("Estado não pode ser vazio.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (string.IsNullOrEmpty(txtPais.Text))
                {
                    MessageBox.Show("País não pode ser vazio.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (string.IsNullOrEmpty(txtSaldo.Text) || !double.TryParse(txtSaldo.Text, out double saldo) || saldo < 0)
                {
                    MessageBox.Show("Saldo inválido. Deve ser um número não negativo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                cliente = new Cliente(txtCPF.Text, txtNomeCliente.Text, txtSexo.Text, txtCidade.Text, txtLagradouro.Text, txtEstado.Text, txtPais.Text, saldo);
                listaclientes.Add(cliente);
                MessageBox.Show("Cliente Adicionado com Sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao adicionar cliente: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
