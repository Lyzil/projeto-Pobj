﻿using Projeto_Loja_de_peças_de_computador_CRUD;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace Projeto_Loja_de_peças_de_computador_CRUD
//{
public class Cliente 
    {
        private string _cpf;
        private string _nome;
        private string _sexo;
        private string _cidade;
        private string _logradouro;
        private string _estado;
        private string _pais;
        private double _saldo = 0;

    public string CPF
    {
        get { return _cpf; }
        set { _cpf = value; } 
    }

    public string Nome
    {
        get { return _nome; }
        set { _nome = value; }
    }

    public string Sexo
    {
        get { return _sexo; }
        set { _sexo = value; }
    }

    public string Cidade
    {
        get { return _cidade; }
        set { _cidade = value; }
    }

    public string Logradouro
    {
        get { return _logradouro; }
        set { _logradouro = value; }
    }

    public string Estado
    {
        get { return _estado; }
        set { _estado = value; } 
    }

    public string Pais
    {
        get { return _pais; }
        set { _pais = value; } 
    }

    public double Saldo
    {
        get { return _saldo; }
        set
        {
            if (value >= 0)
            {
                _saldo = value;
            }
            else
            {
                throw new ArgumentException("Saldo não pode ser negativo.");
            }
        }
    }
    public Cliente(string cpf, string nome,string sexo,string cidade, string logradouro, string estado, string pais, double saldo)
        {
            _cpf = cpf;
            _nome = nome;
            _sexo = sexo;
            _cidade = cidade;
            _logradouro = logradouro;
            _estado = estado;
            _pais = pais;
            _saldo = saldo;
        }
        public bool AdicionarSaldo (double valor) 

        {
        if (valor <= 0) return false;
        _saldo += valor;
        return true;
    }

        public bool DescontarSaldo (double valor)
    {
        if (valor <= 0)
        {
            return false;
        }

        if (_saldo >= valor)
        {
            _saldo -= valor;
            return true;
        }

        return false;
    }
}
