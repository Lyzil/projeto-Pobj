﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    public partial class frmFazerPedido : Form
    {
        List<Cliente> listClientes;
        List<Produto> listprodutos;
        List<PedidoCompra> listapedidos;
        private PedidoCompra pedidoAtual; // Pedido que está sendo montado

        public frmFazerPedido(List<Cliente> clientes, List<Produto> produtos)
        {
            InitializeComponent();
            this.listClientes = clientes;
            this.listprodutos = produtos;
            listapedidos = new List<PedidoCompra>();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            lvwExibirInfoCliente.Items.Clear(); // Limpa o ListView antes de buscar

            string termoPesquisa = txtPesquisarCliente.Text.Trim();
            if (string.IsNullOrEmpty(termoPesquisa))
            {
                MessageBox.Show("Por favor, insira um nome ou CPF para pesquisar.");
                return;
            }

            bool encontrado = false;

            foreach (var cliente in listClientes)
            {
                if ((rbtnCPF.Checked && cliente.CPF == termoPesquisa) ||
                    (rbtnNome.Checked && cliente.Nome.IndexOf(termoPesquisa, StringComparison.OrdinalIgnoreCase) >= 0))
                {
                    // Adiciona o cliente ao ListView
                    ListViewItem item = new ListViewItem(cliente.CPF);
                    item.SubItems.Add(cliente.Nome);
                    item.SubItems.Add(cliente.Sexo);
                    item.SubItems.Add(cliente.Logradouro);
                    item.SubItems.Add(cliente.Cidade);
                    item.SubItems.Add(cliente.Estado);
                    item.SubItems.Add(cliente.Pais);
                    item.SubItems.Add(cliente.Saldo.ToString("C"));
                    lvwExibirInfoCliente.Items.Add(item);
                    encontrado = true;
                }
            }

            if (!encontrado)
            {
                MessageBox.Show("Nenhum usuário encontrado.");
            }
        }

        private void lvwExibirInfoCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvwExibirInfoCliente.SelectedItems.Count == 0)
                return;

            // Obter CPF do cliente selecionado
            string cpfSelecionado = lvwExibirInfoCliente.SelectedItems[0].Text;

            if (pedidoAtual != null && pedidoAtual.Cliente.CPF != cpfSelecionado)
            {
                MessageBox.Show($"O pedido atual está vinculado ao cliente {pedidoAtual.Cliente.Nome}. " +
                                "Finalize ou cancele o pedido atual antes de selecionar outro cliente.");

                // Desmarcar a seleção para evitar confusão
                lvwExibirInfoCliente.SelectedItems.Clear();
            }
        }


        private void btnAddProdutoPedido_Click(object sender, EventArgs e)
        {
            if (lvwExibirInfoCliente.SelectedItems.Count == 0)
            {
                MessageBox.Show("Selecione um cliente antes de adicionar produtos.");
                return;
            }

            string cpfSelecionado = lvwExibirInfoCliente.SelectedItems[0].Text;

            if (pedidoAtual != null && pedidoAtual.Cliente.CPF != cpfSelecionado)
            {
                MessageBox.Show($"O pedido atual está vinculado ao cliente {pedidoAtual.Cliente.Nome}. " +
                                "Finalize ou cancele o pedido antes de realizar ações com outro cliente.");
                return;
            }

            // Inicializar o pedido se for nulo
            if (pedidoAtual == null)
            {
                Cliente clienteSelecionado = listClientes.FirstOrDefault(c => c.CPF == cpfSelecionado);

                if (clienteSelecionado == null)
                {
                    MessageBox.Show("Cliente inválido.");
                    return;
                }

                pedidoAtual = new PedidoCompra
                {
                    Cliente = clienteSelecionado,
                    Itens = new List<ItemCompra>(),
                    DataHora = DateTime.Now,
                    Status = "em andamento"
                };
            }

            // Adicionar produto ao pedido
            Produto produtoSelecionado = (Produto)cmbNomeProduto.SelectedItem;

            if (produtoSelecionado == null)
            {
                MessageBox.Show("Por favor, selecione um produto.");
                return;
            }

            int quantidade;
            if (!int.TryParse(txtQtd.Text, out quantidade) || quantidade <= 0)
            {
                MessageBox.Show("Por favor, insira uma quantidade válida.");
                return;
            }

            if (quantidade > produtoSelecionado.Estoque)
            {
                MessageBox.Show("Quantidade insuficiente no estoque.");
                return;
            }

            ItemCompra item = new ItemCompra(produtoSelecionado, quantidade);
            pedidoAtual.Itens.Add(item);

            produtoSelecionado.Estoque -= quantidade;

            ListViewItem listItem = new ListViewItem(produtoSelecionado.Nome);
            listItem.SubItems.Add(quantidade.ToString());
            listItem.SubItems.Add((produtoSelecionado.Valor * quantidade).ToString("C")); // Subtotal
            lvwExibirPedido.Items.Add(listItem);

            MessageBox.Show("Produto adicionado ao pedido.");
        }

        private void btnCancelarPedido_Click(object sender, EventArgs e)
        {
            if (pedidoAtual == null || pedidoAtual.Itens.Count == 0)
            {
                MessageBox.Show("Nenhum pedido em andamento para cancelar.");
                return;
            }

            DialogResult confirmacao = MessageBox.Show(
                "Deseja cancelar o pedido atual? Todos os produtos serão devolvidos ao estoque.",
                "Confirmação de Cancelamento",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirmacao == DialogResult.Yes)
            {
                foreach (var item in pedidoAtual.Itens)
                {
                    item.Produto.Estoque += (int)item.Quantidade;
                }

                pedidoAtual = null;
                lvwExibirPedido.Items.Clear();
                MessageBox.Show("Pedido atual cancelado com sucesso!");
            }
        }

        private void btnFinalizarPedido_Click(object sender, EventArgs e)
        {
            if (pedidoAtual == null || pedidoAtual.Itens.Count == 0)
            {
                MessageBox.Show("Nenhum pedido em andamento para finalizar.");
                return;
            }

            double valorTotal = pedidoAtual.Itens.Sum(i => i.Produto.Valor * i.Quantidade);
            if (pedidoAtual.Cliente.Saldo < valorTotal)
            {
                MessageBox.Show("O cliente não possui saldo suficiente para finalizar o pedido.");
                return;
            }

            pedidoAtual.Cliente.DescontarSaldo(valorTotal);
            pedidoAtual.Status = "concluido";
            listapedidos.Add(pedidoAtual);

            MessageBox.Show(pedidoAtual.ImprimirPedido());

            pedidoAtual = null;
            lvwExibirPedido.Items.Clear();
        }

        private void frmFazerPedido_Load(object sender, EventArgs e)
        {
            AtualizarComboBoxProdutos();

            lvwExibirInfoCliente.SelectedIndexChanged += lvwExibirInfoCliente_SelectedIndexChanged;

        }

        public void AtualizarComboBoxProdutos()
        {
            cmbNomeProduto.DataSource = null;
            cmbNomeProduto.DataSource = listprodutos;
            cmbNomeProduto.DisplayMember = "Nome";
            cmbNomeProduto.ValueMember = "ID";
        }

        private void btnAddSaldo_Click(object sender, EventArgs e)
        {
            if (lvwExibirInfoCliente.SelectedItems.Count == 0)
            {
                MessageBox.Show("Selecione um cliente antes de adicionar saldo.");
                return;
            }

            // Obtém o CPF do cliente selecionado
            string cpf = lvwExibirInfoCliente.SelectedItems[0].Text;

            if (pedidoAtual != null && pedidoAtual.Cliente.CPF != cpf)
            {
                MessageBox.Show($"O pedido atual está vinculado ao cliente {pedidoAtual.Cliente.Nome}. " +
                                "Finalize ou cancele o pedido antes de realizar ações com outro cliente.");
                return;
            }
            Cliente clienteSelecionado = listClientes.FirstOrDefault(c => c.CPF == cpf);

            if (clienteSelecionado == null)
            {
                MessageBox.Show("Cliente inválido.");
                return;
            }

            // Verifica se o valor do saldo a ser adicionado é válido
            double saldoAdicionado;
            if (double.TryParse(txtSaldoAdicionado.Text, out saldoAdicionado) && saldoAdicionado > 0)
            {
                bool sucesso = clienteSelecionado.AdicionarSaldo(saldoAdicionado);

                if (sucesso)
                {
                    MessageBox.Show($"Saldo de {saldoAdicionado:C} adicionado com sucesso ao cliente {clienteSelecionado.Nome}.");
                }
                else
                {
                    MessageBox.Show("Falha ao adicionar saldo.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um valor válido para o saldo.");
            }
        }

    }
}