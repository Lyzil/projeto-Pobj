﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    public class ItemCompra 
    {
		private double _quantidade;

        private Produto _produto;

        public Produto Produto
        {
            get { return _produto; }
            set { _produto = value; }
        }

        public double Quantidade
		{
			get { return _quantidade; }
			set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("A quantidade deve ser maior que zero.");
                }
                _quantidade = value;
            }
        }
        public ItemCompra(Produto produto, double quantidade)
        {
            _produto = produto;
            _quantidade = quantidade;
        }
    }
}