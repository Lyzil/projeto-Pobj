﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    public class PedidoCompra
    {
        private static int _proximoId = 1; // Controle estático para IDs
        private int _id;
        private DateTime _datahora;
        private string _status;
        private Cliente _cliente;

        public PedidoCompra()
        {
            Itens = new List<ItemCompra>();
            _id = _proximoId++; // Atribui e incrementa o próximo ID
            _datahora = DateTime.Now; // Define a data e hora atual por padrão
            _status = "em andamento"; // Define um status inicial
        }

        public Cliente Cliente
        {
            get { return _cliente; }
            set { _cliente = value; }
        }

        public List<ItemCompra> Itens { get; set; }

        public int ID
        {
            get { return _id; }
        }

        public DateTime DataHora
        {
            get { return _datahora; }
            set { _datahora = value; }
        }

        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }

        public double CalcularValorTotal()
        {
            double valorTotal = 0;

            foreach (ItemCompra item in Itens)
            {
                valorTotal += item.Quantidade * item.Produto.Valor;
            }

            return valorTotal;
        }

        public bool EfetivarVenda()
        {
            _status = "concluido";
            return true;
        }

        public bool CancelarVenda()
        {
            if (_status == "concluido")
            {
                return false;
            }

            _status = "cancelado";

            foreach (var item in Itens)
            {
                item.Produto.Estoque += (int)item.Quantidade;
            }

            return true;
        }

        public string ImprimirPedido()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Pedido ID: {ID}");
            sb.AppendLine($"Data/Hora: {DataHora}");
            sb.AppendLine($"Status: {Status}");
            sb.AppendLine("Itens:");

            foreach (ItemCompra item in Itens)
            {
                sb.AppendLine($"- {item.Produto.Nome}: {item.Quantidade} x {item.Produto.Valor:C2} = {item.Quantidade * item.Produto.Valor:C2}");
            }

            sb.AppendLine($"\nTotal: {CalcularValorTotal():C2}");
            return sb.ToString();
        }
    }
}
