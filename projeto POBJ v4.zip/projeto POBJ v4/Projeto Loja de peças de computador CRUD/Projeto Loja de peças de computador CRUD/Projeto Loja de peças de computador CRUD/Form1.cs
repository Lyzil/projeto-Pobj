﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Loja_de_peças_de_computador_CRUD
{
    public partial class Form1 : Form
    {
        List<Cliente> listClientes = new List<Cliente>();
        List<Produto> listprodutos = new List<Produto>();
        public Form1()
        {
            Cliente cliente = new Cliente("40983598765", "jose farias", "m", "Cubatão", "avenida silva antoni, rua farias junior, 40", "São paulo", "Brasil", 2500); //<--------- colocar dados para teste (já criar objetos para a lista por default para teste
            listClientes.Add(cliente);
            Cliente cliente2 = new Cliente("65428503591", "jose alencar", "m", "Santos", "avenida paulo robert, rua farias neto, 10", "São paulo", "Brasil", 4000);
            listClientes.Add(cliente2);

            Produto produtado = new Produto(0, "Teclado", 100, 60); // produtos criados ao iniciar
            listprodutos.Add(produtado);
            Produto produtado2 = new Produto(10, "mouse", 200, 80);
            listprodutos.Add(produtado2);

            InitializeComponent();
        }
        frmAdicionarProduto frmAdicionarProdutoobj;
        frmAdicionarCliente frmAdicionarClienteobj;
        frmFazerPedido frmFazerPedidoobj;
        private void tsmiProdutos_Click(object sender, EventArgs e)
        {

            if (frmAdicionarProdutoobj == null || frmAdicionarProdutoobj.IsDisposed)
            {
                frmAdicionarProdutoobj = new frmAdicionarProduto(listprodutos);
                frmAdicionarProdutoobj.MdiParent = this;
                frmAdicionarProdutoobj.Show();
            }
            else 
            { frmAdicionarProdutoobj.Activate(); return; }

        }

        private void tsmiCliente_Click(object sender, EventArgs e)
        {
            if (frmAdicionarClienteobj == null || frmAdicionarClienteobj.IsDisposed)
            {
                frmAdicionarClienteobj = new frmAdicionarCliente(listClientes);
                frmAdicionarClienteobj.MdiParent = this;
                frmAdicionarClienteobj.Show();
            }
            else { frmAdicionarClienteobj.Activate(); return;}
        }

        private void tsmiPedido_Click(object sender, EventArgs e)
        {
            if (frmFazerPedidoobj == null || frmFazerPedidoobj.IsDisposed)
            {
                frmFazerPedidoobj = new frmFazerPedido(listClientes, listprodutos);
                frmFazerPedidoobj.MdiParent = this;
                frmFazerPedidoobj.Show();
            }
            else
            {
                frmFazerPedidoobj.AtualizarComboBoxProdutos(); // Atualiza a lista de produtos
                frmFazerPedidoobj.Activate();
            }
        }

    }
}
